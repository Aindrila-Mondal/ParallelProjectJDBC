package com.cg.ui;

import java.sql.SQLException;

import java.util.Scanner;

import com.cg.service.IService;
import com.cg.service.IServiceImpl;

public class AccountMain 
{
	public static void main(String[] args) throws ClassNotFoundException, SQLException 
	{
		IService p2=new IServiceImpl();
		Scanner sc=new Scanner(System.in);
		while(true)
		{
			System.out.println("1.create account");
			System.out.println("2.show balance");
			System.out.println("3.deposit into account");
			System.out.println("4.withdraw from account");
			System.out.println("5.fund transfer");
			System.out.println("6. display account");
			int opt=sc.nextInt();
			switch(opt)
			{
			case 1:  System.out.println("enter Account number");
			         long accno=sc.nextLong();
                       String regEx="[0-9]{6}";
                      String s=accno+"";
                      while(!(s.matches(regEx)))
                      {
                    	  accno=sc.nextLong();
                    	  s=accno+"";
                      }
				      System.out.println("enter name");
				      String name=sc.next();
				      System.out.println("enter balance");
				      double balance=sc.nextDouble();
				      
				      p2.createAccount(accno, name, balance);
				      break;
				      
			case 2:   System.out.println("enter acc no to show balance");	  
			          long accno1=sc.nextLong();
			          p2.showBalance(accno1);
			          break;
			case 3:   System.out.println("enter amount to be deposited"); 
			          double deposit=sc.nextDouble();
			          System.out.println("enter acc no to deposit money");	  
			          long accno2=sc.nextLong();
			          p2.deposit(accno2, deposit);
			          break;
			case 4:   System.out.println("enter amount to be withdrawn"); 
				        double withdraw=sc.nextDouble();
				        System.out.println("enter acc no to withdraw money");	  
				        long accno5=sc.nextLong();
				        p2.deposit(accno5, withdraw);
				        break;    
						          
			          
			          
			case 5:    System.out.println("enter amount to be transfered"); 
				        double fundamt=sc.nextDouble();
				        System.out.println("enter acc no from where  money to be transfered");	  
				        long accno3=sc.nextLong();  
				        System.out.println("enter acc no where  money to be transfered");	  
				        long accno4=sc.nextLong();  
				        p2.fundtransfer(accno3, accno4, fundamt);
				        break;
			case 6:    p2.display();	        
					break;
			default:  System.out.println("wrong choice");			
			
			}  
		}
		
		
		
		
		
		
	}

	}


