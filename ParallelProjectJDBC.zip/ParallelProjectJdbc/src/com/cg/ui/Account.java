package com.cg.ui;

import java.util.ArrayList;
import java.util.List;



public class Account 
{
	private Long AccNo;
	private String Name;
	private double balance;
	
	public Long getAccNo() {
		return AccNo;
	}
	public void setAccNo(Long accNo) {
		AccNo = accNo;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "Account [AccNo=" + AccNo + ", Name=" + Name + ", balance=" + balance + "]";
	}
	
	

	}



