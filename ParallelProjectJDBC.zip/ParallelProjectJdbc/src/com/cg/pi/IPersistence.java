package com.cg.pi;

import java.sql.SQLException;

public interface IPersistence 
{
public void createAccount(long AccNo,String Name,Double balance) throws ClassNotFoundException, SQLException;
public void showBalance(long AccNo) throws ClassNotFoundException, SQLException;
public void  deposit(long AccNo,double deposit) throws ClassNotFoundException, SQLException;
public void  withdraw(long AccNo,double withdraw) throws ClassNotFoundException, SQLException;
public void  fundtransfer(long AccNo1,long AccNo2,double fundamt) throws ClassNotFoundException, SQLException;
public void  display() throws ClassNotFoundException, SQLException;


}
