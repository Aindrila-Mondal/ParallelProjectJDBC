package com.cg.pi;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;



public class IPersistenceImpl implements IPersistence
{
	private PreparedStatement ps=null;
	private Connection con=null;
    void getConnection() throws ClassNotFoundException, SQLException
    {
    	Class.forName("");
    	String url="";
    	String user="";
    	String pass="";
    	con=DriverManager.getConnection(url, user, pass);
    }
    
	@Override
	public void createAccount(long AccNo, String Name, Double balance) throws ClassNotFoundException, SQLException 
	{
		getConnection();
		ps=con.prepareStatement("insert into Account values(?,?,?)");
		ps.setLong(1, AccNo);
		ps.setString(2, Name);
		ps.setDouble(3, balance);
		ps.executeUpdate();
		
		ps=con.prepareStatement("select * from Account where Name=?");
		ps.setString(1,Name);
		ResultSet rs=ps.executeQuery();
		if(rs.next())
		{
			
			System.out.println("Account created successfully"+rs.getInt(1));
		}
		System.out.println("Account created successfully");
		con.close();
	}

	@Override
	public void showBalance(long AccNo) throws ClassNotFoundException, SQLException 
	{
		getConnection();
		ps=con.prepareStatement("select balance from Account where AccNo=?");
		ps.setLong(1, AccNo);
		ResultSet rs=ps.executeQuery();
		if(rs.next())
		{
			double balance=rs.getDouble(1);
		}
	    con.close();
	}

	@Override
	public void deposit(long AccNo,double deposit) throws ClassNotFoundException, SQLException 
	{
		
		getConnection();
		ps=con.prepareStatement("select * from Account where AccNo=?");
		ps.setLong(1, AccNo);
		ResultSet rs=ps.executeQuery();
		double bal1=0;
		if(rs.next())
		{
			double balance=rs.getDouble(3);
			bal1=balance+deposit;
			}
		
		ps=con.prepareStatement("update Account set balance=? where AccNo=?");
		ps.setDouble(1, bal1);
		ps.setLong(2, AccNo);
		ps.executeUpdate();
	
	
		
		ps=con.prepareStatement("insert into Transaction values(?,?,?.?)");
		ps.setString(1,"credit");
		ps.setDouble(2,deposit);
		ps.setDate(3,Date.valueOf(LocalDate.now()));
		String t=LocalTime.now()+"";
		ps.setString(4,t);
		ps.executeUpdate();
		con.close();		
				
	}
		
	@Override
	public void withdraw(long AccNo,double withdraw) throws ClassNotFoundException, SQLException 
	{
		getConnection();
		ps=con.prepareStatement("select * from Account where AccNo=?");
		ps.setLong(1, AccNo);
		ResultSet rs=ps.executeQuery();
		double bal1=0;
		if(rs.next())
		{
			double balance=rs.getDouble(3);
			bal1=balance-withdraw;
			}
		
		ps=con.prepareStatement("update Account set balance=? where AccNo=?");
		ps.setDouble(1, bal1);
		ps.setLong(2, AccNo);
		ps.executeUpdate();
	   
	
		
		ps=con.prepareStatement("insert into Transaction values(?,?,?.?,?)");
		        ps.setLong(1, AccNo);
		        ps.setDouble(2,withdraw);
				ps.setString(3,"debit");
				ps.setDate(4,Date.valueOf(LocalDate.now()));
				String t=LocalTime.now()+"";
				ps.setString(5,t);
				ps.executeUpdate();
				con.close();
		}

	
	@Override
	public void fundtransfer(long AccNo1, long AccNo2, double fundamt) throws ClassNotFoundException, SQLException 
	{
		
		getConnection();
		ps=con.prepareStatement("select * from Account where AccNo=?");
		ps.setLong(1, AccNo1);
		ResultSet rs2=ps.executeQuery();
		double f=0;
		if(rs2.next())
		{
			double balance=rs2.getDouble(3);
			f=balance-fundamt;
			}
		
		ps=con.prepareStatement("update Account set balance=? where AccNo=?");
		ps.setDouble(1, f);
		ps.setLong(2, AccNo1);
		ps.executeUpdate();
		
		ps=con.prepareStatement("select * from Account where AccNo=?");
		ps.setLong(1, AccNo2);
		ResultSet rs3=ps.executeQuery();
		double f1=0;
		if(rs3.next())
		{
			double balance=rs3.getDouble(3);
			f1=balance+fundamt;
		}
		
		ps=con.prepareStatement("update Account set balance=? where AccNo=?");
		ps.setDouble(1, f1);
		ps.setLong(2, AccNo1);
		ps.executeUpdate();
		
     }
	@Override
	public void display() throws ClassNotFoundException, SQLException 
	{
		
		getConnection();
		ps=con.prepareStatement("select * from Account ");
		ResultSet rs=ps.executeQuery();
		if(rs.next())
		{
			System.out.println(rs.getLong(1));
			System.out.println(rs.getString(2));
			System.out.println(rs.getDouble(3));
			
			
	    }
		ps.executeUpdate();
		
		
		ps=con.prepareStatement("select * from Transaction ");
		ResultSet rs1=ps.executeQuery();
		if(rs.next())
		{
			System.out.println(rs1.getLong(1));
			System.out.println(rs1.getDouble(2));
			System.out.println(rs1.getString(3));
			System.out.println(rs1.getDate(4));
			System.out.println(rs1.getString(5));
			
	    }
		ps.executeUpdate();
		
		
	
}


}
