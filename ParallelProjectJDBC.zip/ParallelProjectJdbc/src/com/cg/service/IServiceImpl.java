package com.cg.service;

import java.sql.SQLException;

import com.cg.pi.IPersistence;
import com.cg.pi.IPersistenceImpl;

public class IServiceImpl implements IService
{
	
    IPersistence p1=new IPersistenceImpl();
	@Override
	public void createAccount(long AccNo, String Name, Double balance) throws ClassNotFoundException, SQLException
	{
		p1.createAccount(AccNo, Name, balance);
	}

	@Override
	public void showBalance(long AccNo) throws ClassNotFoundException, SQLException 
	{
		// TODO Auto-generated method stub
		p1.showBalance(AccNo);
	}

	@Override
	public void deposit(long AccNo, double deposit) throws ClassNotFoundException, SQLException 
	{
		// TODO Auto-generated method stub
		p1.deposit(AccNo, deposit);
	}

	@Override
	public void withdraw(long AccNo, double withdraw) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		p1.withdraw(AccNo, withdraw);
	}

	@Override
	public void fundtransfer(long AccNo1, long AccNo2, double fundamt) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		p1.fundtransfer(AccNo1, AccNo2, fundamt);
	}

	@Override
	public void display() throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		p1.display();
	}

}



